#define PERL_LIB "C:\\perl\\lib\\CORE\\perl58.lib"
